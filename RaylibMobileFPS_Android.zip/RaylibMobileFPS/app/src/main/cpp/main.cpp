#include "raylib.h"
#include "raymath.h"
#include <vector>
#include <cmath>
#include <algorithm>

struct Enemy {
    Vector3 pos;
    float hp = 100.0f;
    bool alive = true;
};

static bool InRect(Vector2 p, Rectangle r) {
    return CheckCollisionPointRec(p, r);
}

static bool MenuButton(Rectangle r, const char *label, Vector2 tap, bool tapped, Color fill) {
    DrawRectangleRounded(r, 0.16f, 8, fill);
    DrawRectangleRoundedLines(r, 0.16f, 8, Fade(RAYWHITE, 0.75f));
    int font = 25;
    int tw = MeasureText(label, font);
    DrawText(label, (int)(r.x + (r.width - tw) / 2), (int)(r.y + (r.height - font) / 2), font, RAYWHITE);
    return tapped && CheckCollisionPointRec(tap, r);
}

int main() {
    const int W = 1280;
    const int H = 720;
    InitWindow(W, H, "Raylib Mobile FPS");
    SetTargetFPS(60);

    enum class Screen { MAIN_MENU, MODE_SELECT, MAP_SELECT, MATCH };
    Screen screen = Screen::MAIN_MENU;
    int selectedMode = 0; // 0 team fight, 1 bomb mission, 2 ranked
    int selectedMap = 0;  // 0 Depot, 1 Hangar, 2 Ruins
    int previousTouchCount = 0;
    const char *modeNames[] = {"TEAM FIGHT", "BOMB MISSION", "RANKED MATCH"};
    const char *mapNames[] = {"DEPOT", "HANGAR", "RUINS"};

    Camera3D camera{};
    camera.position = {0.0f, 1.7f, 8.0f};
    camera.target = {0.0f, 1.7f, 7.0f};
    camera.up = {0.0f, 1.0f, 0.0f};
    camera.fovy = 75.0f;
    camera.projection = CAMERA_PERSPECTIVE;

    float hp = 100.0f;
    float fireTimer = 0.0f;
    float spawnTimer = 0.0f;
    float damageFlash = 0.0f;
    int kills = 0;
    int ammo = 12;
    const int magazineSize = 12;
    float reloadTimer = 0.0f;

    std::vector<Enemy> enemies;
    auto spawnEnemy = [&]() {
        enemies.push_back({
            {(float)GetRandomValue(-14, 14), 0.85f,
             (float)GetRandomValue(-15, -5)},
            100.0f, true
        });
    };
    for (int i = 0; i < 5; ++i) spawnEnemy();

    // Touch controls: left half = virtual stick, right half = look.
    int moveFinger = -1;
    int lookFinger = -1;
    Vector2 stickCenter{150, H - 150};
    Vector2 stickPos = stickCenter;
    Vector2 lookLast{0, 0};
    Vector2 lookDelta{0, 0};
    bool firing = false;
    bool reloadPressed = false;

    const Rectangle fireButton{W - 190, H - 190, 145, 145};
    const Rectangle reloadButton{W - 330, H - 105, 115, 65};

    while (!WindowShouldClose()) {
        float dt = GetFrameTime();
        dt = std::min(dt, 0.05f);

        // One-tap UI input works with both touchscreens and desktop mouse.
        Vector2 tapPos = GetMousePosition();
        bool tapped = IsMouseButtonPressed(MOUSE_BUTTON_LEFT);
        int uiTouchCount = GetTouchPointCount();
        if (uiTouchCount > 0 && previousTouchCount == 0) {
            tapPos = GetTouchPosition(0);
            tapped = true;
        }
        previousTouchCount = uiTouchCount;

        if (screen != Screen::MATCH) {
            BeginDrawing();
            DrawRectangleGradientV(0, 0, W, H, Color{18, 29, 48, 255}, Color{5, 8, 16, 255});
            // Abstract arena silhouettes behind the menu.
            DrawRectangle(0, H - 175, W, 175, Fade(BLACK, 0.38f));
            for (int i = 0; i < 7; ++i) {
                int x = 40 + i * 190;
                DrawRectangle(x, H - 220 - (i % 3) * 28, 105, 220 + (i % 3) * 28, Fade(BLUE, 0.10f));
            }
            DrawText("RAY ARENA", 54, 48, 48, RAYWHITE);
            DrawText("MOBILE TACTICAL ARENA  |  OFFLINE BOTS", 58, 103, 18, SKYBLUE);

            if (screen == Screen::MAIN_MENU) {
                DrawText("PLAY AGAINST BOTS", 58, 205, 27, LIGHTGRAY);
                if (MenuButton({58, 275, 430, 82}, "PLAY", tapPos, tapped, Color{28, 105, 165, 255}))
                    screen = Screen::MODE_SELECT;
                if (MenuButton({58, 375, 430, 64}, "HOW TO PLAY", tapPos, tapped, Color{45, 55, 72, 255}))
                    screen = Screen::MODE_SELECT;
                DrawText("Choose a mode, then choose an arena.", 60, 475, 20, GRAY);
                DrawText("Prototype build - all matches are offline", 60, H - 48, 17, LIGHTGRAY);
            } else if (screen == Screen::MODE_SELECT) {
                DrawText("SELECT GAME MODE", 58, 190, 30, RAYWHITE);
                const char *descriptions[] = {
                    "Two teams. First side to the score limit wins.",
                    "Round objective with attacking and defending bots.",
                    "Harder bots, rank points and promotion progress."
                };
                for (int i = 0; i < 3; ++i) {
                    Rectangle card{58, 250.0f + i * 112.0f, 760, 88};
                    DrawRectangleRounded(card, 0.12f, 8, Fade(i == selectedMode ? BLUE : DARKBLUE, 0.48f));
                    DrawRectangleRoundedLines(card, 0.12f, 8, Fade(WHITE, 0.65f));
                    DrawText(modeNames[i], 82, (int)card.y + 12, 24, RAYWHITE);
                    DrawText(descriptions[i], 82, (int)card.y + 48, 17, LIGHTGRAY);
                    if (tapped && CheckCollisionPointRec(tapPos, card)) {
                        selectedMode = i;
                        screen = Screen::MAP_SELECT;
                    }
                }
                if (MenuButton({865, H - 105, 220, 64}, "BACK", tapPos, tapped, Color{55, 60, 72, 255}))
                    screen = Screen::MAIN_MENU;
            } else if (screen == Screen::MAP_SELECT) {
                DrawText("SELECT ARENA", 58, 190, 30, RAYWHITE);
                const char *mapDescriptions[] = {"Industrial storage yard", "Large indoor training site", "Abandoned stone outpost"};
                for (int i = 0; i < 3; ++i) {
                    Rectangle card{58.0f + i * 365.0f, 265, 330, 230};
                    Color tint = i == 0 ? Color{87, 105, 122, 255} : (i == 1 ? Color{83, 91, 108, 255} : Color{113, 91, 72, 255});
                    DrawRectangleRounded(card, 0.08f, 8, tint);
                    DrawRectangle((int)card.x + 16, (int)card.y + 16, 298, 130, Fade(BLACK, 0.28f));
                    // Simple illustrated map preview made from shapes.
                    for (int j = 0; j < 4; ++j)
                        DrawRectangle((int)card.x + 28 + j * 68, (int)card.y + 72 - (j % 2) * 24, 42, 58, Fade(LIGHTGRAY, 0.5f));
                    DrawText(mapNames[i], (int)card.x + 20, (int)card.y + 158, 24, WHITE);
                    DrawText(mapDescriptions[i], (int)card.x + 20, (int)card.y + 190, 15, RAYWHITE);
                    if (tapped && CheckCollisionPointRec(tapPos, card)) {
                        selectedMap = i;
                        hp = 100.0f; kills = 0; ammo = magazineSize; reloadTimer = 0.0f;
                        enemies.clear();
                        int botCount = selectedMode == 2 ? 7 : 5;
                        for (int b = 0; b < botCount; ++b) spawnEnemy();
                        camera.position = {0.0f, 1.7f, 8.0f};
                        camera.target = {0.0f, 1.7f, 7.0f};
                        screen = Screen::MATCH;
                    }
                }
                if (MenuButton({865, H - 105, 220, 64}, "BACK", tapPos, tapped, Color{55, 60, 72, 255}))
                    screen = Screen::MODE_SELECT;
            }
            EndDrawing();
            continue;
        }

        // In-match menu button returns to the lobby.
        if (tapped && CheckCollisionPointRec(tapPos, Rectangle{W - 150.0f, 18.0f, 130.0f, 48.0f})) {
            screen = Screen::MAIN_MENU;
            continue;
        }

        firing = false;
        reloadPressed = false;
        lookDelta = {0, 0};

        int touchCount = GetTouchPointCount();
        for (int i = 0; i < touchCount; ++i) {
            int id = GetTouchPointId(i);
            Vector2 p = GetTouchPosition(i);

            if (InRect(p, fireButton)) {
                firing = true;
                continue;
            }
            if (InRect(p, reloadButton)) {
                reloadPressed = true;
                continue;
            }

            if (p.x < W * 0.48f) {
                if (moveFinger == -1 || moveFinger == id) {
                    moveFinger = id;
                    stickPos = p;
                }
            } else {
                if (lookFinger == -1 || lookFinger == id) {
                    if (lookFinger == -1) lookLast = p;
                    else {
                        lookDelta.x += p.x - lookLast.x;
                        lookDelta.y += p.y - lookLast.y;
                        lookLast = p;
                    }
                    lookFinger = id;
                }
            }
        }

        bool moveFound = false, lookFound = false;
        for (int i = 0; i < touchCount; ++i) {
            int id = GetTouchPointId(i);
            if (id == moveFinger) moveFound = true;
            if (id == lookFinger) lookFound = true;
        }
        if (!moveFound) {
            moveFinger = -1;
            stickPos = stickCenter;
        }
        if (!lookFound) lookFinger = -1;

        // Mouse input is useful when testing on desktop.
        if (IsMouseButtonDown(MOUSE_BUTTON_LEFT)) {
            Vector2 mp = GetMousePosition();
            if (InRect(mp, fireButton)) firing = true;
            else if (mp.x > W * 0.48f) lookDelta = GetMouseDelta();
        }
        if (IsKeyDown(KEY_W)) stickPos.y = stickCenter.y - 45;
        if (IsKeyDown(KEY_S)) stickPos.y = stickCenter.y + 45;
        if (IsKeyDown(KEY_A)) stickPos.x = stickCenter.x - 45;
        if (IsKeyDown(KEY_D)) stickPos.x = stickCenter.x + 45;
        if (IsKeyPressed(KEY_SPACE)) firing = true;
        if (IsKeyPressed(KEY_R)) reloadPressed = true;

        // Camera rotation
        Vector3 forward = Vector3Normalize(Vector3Subtract(camera.target, camera.position));
        float yaw = atan2f(forward.x, forward.z);
        float pitch = asinf(Clamp(forward.y, -1.0f, 1.0f));
        yaw -= lookDelta.x * 0.004f;
        pitch = Clamp(pitch - lookDelta.y * 0.004f, -1.25f, 1.25f);
        forward = {
            sinf(yaw) * cosf(pitch),
            sinf(pitch),
            cosf(yaw) * cosf(pitch)
        };

        // Movement from the virtual joystick.
        Vector2 stick = Vector2Subtract(stickPos, stickCenter);
        float stickLen = Vector2Length(stick);
        if (stickLen > 55.0f) stick = Vector2Scale(stick, 55.0f / stickLen);
        Vector2 move = Vector2Scale(stick, 1.0f / 55.0f);
        Vector3 flatForward = Vector3Normalize(Vector3{forward.x, 0, forward.z});
        Vector3 right = Vector3Normalize(Vector3CrossProduct(flatForward, {0, 1, 0}));
        Vector3 delta = Vector3Add(
            Vector3Scale(flatForward, -move.y * 5.0f * dt),
            Vector3Scale(right, move.x * 5.0f * dt)
        );
        camera.position = Vector3Add(camera.position, delta);
        camera.position.x = Clamp(camera.position.x, -18.0f, 18.0f);
        camera.position.z = Clamp(camera.position.z, -18.0f, 18.0f);
        camera.position.y = 1.7f;
        camera.target = Vector3Add(camera.position, forward);

        // Reload
        if (reloadPressed && reloadTimer <= 0.0f && ammo < magazineSize)
            reloadTimer = 1.15f;
        if (reloadTimer > 0.0f) {
            reloadTimer -= dt;
            if (reloadTimer <= 0.0f) ammo = magazineSize;
        }

        // Hitscan-style arcade shooting against simple enemy hitboxes.
        fireTimer -= dt;
        if (firing && fireTimer <= 0.0f && reloadTimer <= 0.0f && ammo > 0 && hp > 0) {
            fireTimer = 0.22f;
            --ammo;
            Ray ray = GetScreenToWorldRay({W * 0.5f, H * 0.5f}, camera);
            float nearest = 10000.0f;
            int hitIndex = -1;
            for (int i = 0; i < (int)enemies.size(); ++i) {
                if (!enemies[i].alive) continue;
                BoundingBox box{
                    Vector3{enemies[i].pos.x - 0.48f, enemies[i].pos.y - 0.7f, enemies[i].pos.z - 0.48f},
                    Vector3{enemies[i].pos.x + 0.48f, enemies[i].pos.y + 0.7f, enemies[i].pos.z + 0.48f}
                };
                RayCollision hit = GetRayCollisionBox(ray, box);
                if (hit.hit && hit.distance < nearest) {
                    nearest = hit.distance;
                    hitIndex = i;
                }
            }
            if (hitIndex >= 0) {
                enemies[hitIndex].hp -= 50.0f;
                if (enemies[hitIndex].hp <= 0.0f) {
                    enemies[hitIndex].alive = false;
                    ++kills;
                }
            }
        }

        // Simple arcade enemy movement and contact damage.
        if (hp > 0.0f) {
            for (auto &e : enemies) {
                if (!e.alive) continue;
                Vector3 toPlayer = Vector3Subtract(camera.position, e.pos);
                toPlayer.y = 0.0f;
                float dist = Vector3Length(toPlayer);
                if (dist > 1.25f) {
                    toPlayer = Vector3Normalize(toPlayer);
                    e.pos = Vector3Add(e.pos, Vector3Scale(toPlayer, 1.35f * dt));
                } else {
                    hp -= 16.0f * dt;
                    damageFlash = 0.15f;
                }
            }
            spawnTimer += dt;
            if (spawnTimer > 5.0f && enemies.size() < 18) {
                spawnTimer = 0.0f;
                spawnEnemy();
            }
        }
        damageFlash = std::max(0.0f, damageFlash - dt);

        // Draw world
        BeginDrawing();
        ClearBackground({18, 24, 34, 255});
        BeginMode3D(camera);
            Color floorColor = selectedMap == 0 ? Color{65, 72, 82, 255} :
                               (selectedMap == 1 ? Color{72, 76, 88, 255} : Color{91, 76, 62, 255});
            DrawPlane({0, 0, 0}, {40, 40}, floorColor);
            DrawGrid(40, 1.0f);
            DrawCube({0, 1.5f, -20}, 40, 3, 1, GRAY);
            DrawCube({0, 1.5f, 20}, 40, 3, 1, GRAY);
            DrawCube({-20, 1.5f, 0}, 1, 3, 40, GRAY);
            DrawCube({20, 1.5f, 0}, 1, 3, 40, GRAY);

            // Low cover blocks
            for (int i = 0; i < 8; ++i) {
                float x = (float)((i % 4) * 8 - 12);
                float z = (i < 4) ? -7.0f : 5.0f;
                DrawCube({x, 0.65f, z}, 2.4f, 1.3f, 2.4f, {95, 105, 118, 255});
                DrawCubeWires({x, 0.65f, z}, 2.4f, 1.3f, 2.4f, DARKGRAY);
            }

            for (const auto &e : enemies) {
                if (!e.alive) continue;
                DrawCube(e.pos, 0.95f, 1.4f, 0.95f, RED);
                DrawCubeWires(e.pos, 0.95f, 1.4f, 0.95f, MAROON);
                DrawSphere({e.pos.x, e.pos.y + 0.95f, e.pos.z}, 0.32f, ORANGE);
            }
        EndMode3D();

        // Crosshair
        DrawLine(W/2 - 12, H/2, W/2 + 12, H/2, RAYWHITE);
        DrawLine(W/2, H/2 - 12, W/2, H/2 + 12, RAYWHITE);

        // HUD
        DrawRectangle(W - 150, 18, 130, 48, Fade(BLACK, 0.70f));
        DrawText("MENU", W - 124, 31, 20, WHITE);
        DrawText(TextFormat("%s  |  %s", modeNames[selectedMode], mapNames[selectedMap]), 280, 28, 18, SKYBLUE);
        DrawRectangle(18, 18, 230, 82, Fade(BLACK, 0.65f));
        DrawText(TextFormat("HP: %d", (int)std::max(0.0f, hp)), 32, 28, 25, LIME);
        DrawText(TextFormat("KILLS: %d", kills), 32, 59, 22, RAYWHITE);

        DrawRectangle(W/2 - 85, 18, 170, 42, Fade(BLACK, 0.65f));
        DrawText(reloadTimer > 0 ? "RELOADING" : TextFormat("AMMO: %d / 12", ammo),
                 W/2 - 72, 29, 20, YELLOW);

        // Virtual joystick
        DrawCircleV(stickCenter, 68, Fade(LIGHTGRAY, 0.18f));
        DrawCircleLines((int)stickCenter.x, (int)stickCenter.y, 68, Fade(WHITE, 0.65f));
        DrawCircleV(stickPos, 29, Fade(WHITE, 0.55f));

        // Fire and reload touch buttons
        DrawCircle(W - 118, H - 118, 70, Fade(RED, 0.62f));
        DrawCircleLines(W - 118, H - 118, 70, RAYWHITE);
        DrawText("FIRE", W - 151, H - 128, 27, WHITE);
        DrawRectangleRec(reloadButton, Fade(DARKGRAY, 0.85f));
        DrawRectangleLinesEx(reloadButton, 2, RAYWHITE);
        DrawText("RELOAD", (int)reloadButton.x + 10, (int)reloadButton.y + 21, 20, WHITE);

        if (damageFlash > 0.0f)
            DrawRectangle(0, 0, W, H, Fade(RED, damageFlash * 1.7f));

        if (hp <= 0.0f) {
            DrawRectangle(0, 0, W, H, Fade(BLACK, 0.78f));
            DrawText("GAME OVER", W/2 - 160, H/2 - 40, 52, RED);
            DrawText(TextFormat("KILLS: %d", kills), W/2 - 65, H/2 + 25, 28, WHITE);
            DrawText("Close and relaunch to play again", W/2 - 190, H/2 + 68, 20, LIGHTGRAY);
        }

        EndDrawing();
    }

    CloseWindow();
    return 0;
}
