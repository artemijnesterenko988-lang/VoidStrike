cmake_minimum_required(VERSION 3.22.1)
project(raylibfps LANGUAGES C CXX)

include(FetchContent)
set(PLATFORM Android CACHE STRING "" FORCE)
set(OPENGL_VERSION "ES 2.0" CACHE STRING "" FORCE)
set(WITH_PIC ON CACHE BOOL "" FORCE)
set(BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(BUILD_GAMES OFF CACHE BOOL "" FORCE)
set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)

FetchContent_Declare(
    raylib
    GIT_REPOSITORY https://github.com/raysan5/raylib.git
    GIT_TAG 5.5
    GIT_SHALLOW TRUE
)
FetchContent_MakeAvailable(raylib)

add_library(raylibfps SHARED main.cpp)
target_compile_features(raylibfps PRIVATE cxx_std_17)
target_compile_definitions(raylibfps PRIVATE PLATFORM_ANDROID)
target_include_directories(raylibfps PRIVATE ${raylib_SOURCE_DIR}/src)

find_library(log-lib log)
find_library(android-lib android)
find_library(egl-lib EGL)
find_library(gles-lib GLESv2)
find_library(openSLES-lib OpenSLES)

target_link_libraries(raylibfps
    raylib
    ${log-lib}
    ${android-lib}
    ${egl-lib}
    ${gles-lib}
    ${openSLES-lib}
)
