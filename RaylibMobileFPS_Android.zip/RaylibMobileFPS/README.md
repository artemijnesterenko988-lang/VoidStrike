# Raylib Mobile FPS (Android)

A small landscape Android first-person arcade shooter built with C++ and raylib 5.5.

## Features
- Main lobby with mode selection and map selection
- Team Fight, Bomb Mission, and Ranked Match menu options (offline bot prototype)
- Three selectable arena themes: Depot, Hangar, and Ruins
- 3D arena, cover blocks, and simple moving enemies
- Touch joystick on the left side
- Swipe on the right side to look around
- FIRE and RELOAD touch buttons
- Health, ammo, and kill counter

## Build with Android Studio
1. Install Android Studio.
2. In SDK Manager, install Android SDK Platform 35, Android SDK Build-Tools, Android NDK (side by side), and CMake 3.22.1.
3. Open this folder (`RaylibMobileFPS`) in Android Studio.
4. Allow Gradle sync. The first native build downloads raylib 5.5 from GitHub, so internet access is required.
5. Select a connected Android device or an Android emulator, then choose **Run**.
6. To create an APK, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The generated debug APK is normally at:
`app/build/outputs/apk/debug/app-debug.apk`

## Menu and modes
- Tap **PLAY**, choose a mode, then tap an arena card to start.
- All modes are currently offline prototypes against bots; mode-specific objectives and team logic are planned for later iterations.
- Tap **MENU** in a match to return to the lobby.

## Controls
- Left virtual joystick: move
- Swipe on the right side: look around
- FIRE: shoot
- RELOAD: refill the magazine

## Notes
- The project targets Android 7.0+ (API 24) and includes `arm64-v8a` and `armeabi-v7a`.
- The CMake project fetches the upstream raylib 5.5 source at configure time. The raylib source is not duplicated in this ZIP.
- This ZIP contains the complete app source and Android project configuration, but not a prebuilt APK. Build it with Android Studio/Android SDK.


## Build APK in GitHub Actions (phone-only workflow)
1. Upload the project files and folders to a GitHub repository on the `main` branch. Include the hidden `.github/workflows/android-apk.yml` file.
2. Open the repository's **Actions** tab and select **Build Android APK**.
3. Tap **Run workflow** (or wait for the first push build).
4. When the run finishes successfully, open the run and download the artifact named `RaylibMobileFPS-debug-apk`.
5. Extract the artifact ZIP; it contains `app-debug.apk`. Android may ask you to allow installation from the browser/files app. Only install APKs you built from your own repository.

The workflow builds a debug APK on GitHub-hosted runners. It requires network access to fetch raylib 5.5 during the CMake configure step.
